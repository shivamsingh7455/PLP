Insert into customer values('shivamsingh7455@gmail.com',23,'Shivam','Shivam@123','8563030333','Shivam_2610');
Insert into customer values('amaan.ahmad7@gmail.com',23,'Amaan','Amaan@123','8563030334','Amaan_2610');
Insert into customer values('yash.yb97@gmail.com',23,'Yash','Yash@123','8563030335','Ybhatia_2610');
Insert into customer values('shivani.sharma702@gmail.com',23,'Shivani','Shivani@123','8563030336','Shivani_2610');
