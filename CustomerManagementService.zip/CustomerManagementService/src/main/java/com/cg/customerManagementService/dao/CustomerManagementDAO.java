package com.cg.customerManagementService.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.customerManagementService.dto.CustomerManagementDTO;

public interface CustomerManagementDAO extends JpaRepository<CustomerManagementDTO,String> {

}
