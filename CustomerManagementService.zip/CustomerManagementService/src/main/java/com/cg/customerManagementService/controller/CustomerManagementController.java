package com.cg.customerManagementService.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.customerManagementService.dto.CustomerManagementDTO;
import com.cg.customerManagementService.services.CustomerManagementService;

@RestController
@CrossOrigin("http://localhost:4200")
public class CustomerManagementController {
	@Autowired
	private CustomerManagementService customerManagementService;
	
	final static Logger logger=Logger.getLogger(CustomerManagementService.class);
	
	@GetMapping(value="/customer")
	public ResponseEntity<List<CustomerManagementDTO>> getAllCustomer() {
		List<CustomerManagementDTO> customers=customerManagementService.getAllCustomer();
		logger.info("All customer details is fetched.");
		return new ResponseEntity<List<CustomerManagementDTO>>(customers, HttpStatus.OK);
	}

	@GetMapping(value="/customer/{customerEmail}")
	public ResponseEntity<CustomerManagementDTO> getCustomerById(@PathVariable("customerEmail") String customerEmail) {
		CustomerManagementDTO customer =customerManagementService.getCustomerById(customerEmail).get();
		logger.info("Customer is Email id: "+customerEmail+" is searched.");
		return new ResponseEntity<CustomerManagementDTO>(customer,HttpStatus.OK);
	}

	@DeleteMapping(value="/customer/delete/{customerEmail}")
	public ResponseEntity<String> deleteCustomerById(@RequestBody String customerEmail) {
		customerManagementService.deleteCustomerById(customerEmail);
		logger.info("Customer with Email id: "+customerEmail+" is deleted.");
		return new ResponseEntity<String>("Succesfully Deleted",HttpStatus.OK);
	}

	@PostMapping(value="/customer/new")
	public ResponseEntity<CustomerManagementDTO> signup(@RequestBody CustomerManagementDTO customer) {
		CustomerManagementDTO result =customerManagementService.signup(customer);
		logger.info("New customer with Email id: "+customer.getCustomerEmail()+" is added.");
		return new ResponseEntity<CustomerManagementDTO>(result,HttpStatus.OK);	
	}
	
	@PutMapping(value= "/customer/update/{customerEmail}")
	public ResponseEntity<CustomerManagementDTO> updateCustomerById(@RequestBody() CustomerManagementDTO customer,@PathVariable("customerEmail") String customerEmail){
        CustomerManagementDTO result =customerManagementService.updateCustomerById(customer,customerEmail);
		logger.info("Customer with Email id: "+customerEmail+" is updated.");
		return new ResponseEntity<CustomerManagementDTO>(result,HttpStatus.OK);
    }

}
