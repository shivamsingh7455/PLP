package com.cg.customerManagementService.services;

import java.util.List;
import java.util.Optional;

import com.cg.customerManagementService.dto.CustomerManagementDTO;

public interface CustomerManagementService {
	List<CustomerManagementDTO> getAllCustomer();
	Optional<CustomerManagementDTO> getCustomerById(String customerEmail);
	CustomerManagementDTO signup(CustomerManagementDTO newCustomer);
	CustomerManagementDTO updateCustomerById(CustomerManagementDTO customer, String customerEmail);
	void deleteCustomerById(String customerEmail);
}
