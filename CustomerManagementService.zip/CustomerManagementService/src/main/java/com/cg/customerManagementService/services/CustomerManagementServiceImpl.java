package com.cg.customerManagementService.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.customerManagementService.dao.CustomerManagementDAO;
import com.cg.customerManagementService.dto.CustomerManagementDTO;
import com.cg.customerManagementService.exception.NotFoundException;

@Service
public class CustomerManagementServiceImpl implements CustomerManagementService {
	@Autowired
	private CustomerManagementDAO customerManagementDao;

	@Override
	public List<CustomerManagementDTO> getAllCustomer() {
		return (List<CustomerManagementDTO>) customerManagementDao.findAll();
	}

	@Override
	public Optional<CustomerManagementDTO> getCustomerById(String customerEmail) {
		if(customerManagementDao.existsById(customerEmail)) {
			return customerManagementDao.findById(customerEmail);
		}
		else {
			throw new NotFoundException("Customer with id :"+customerEmail+" not found");
		}
	}

	@Override
	public CustomerManagementDTO signup(CustomerManagementDTO newCustomer) {
		if(!customerManagementDao.existsById(newCustomer.getCustomerEmail())) {
			return customerManagementDao.save(newCustomer);
		}
		else {
			throw new NotFoundException("Customer already present with this id: "+newCustomer.getCustomerEmail());
		}	
	}

	@Override
	public void deleteCustomerById(String customerEmail) {
		if(customerManagementDao.existsById(customerEmail)) {
			customerManagementDao.deleteById(customerEmail);
		}
		else {
			throw new NotFoundException("Customer with id :"+customerEmail+" not found");
		}
	}

	@Override
	public CustomerManagementDTO updateCustomerById(CustomerManagementDTO customer, String customerEmail) {
		if(customerManagementDao.existsById(customerEmail)) {
			return customerManagementDao.save(customer);
		}
		else {
			throw new NotFoundException("Cant find customer");		
		}
	}

}
