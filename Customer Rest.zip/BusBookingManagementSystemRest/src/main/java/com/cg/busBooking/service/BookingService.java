package com.cg.busBooking.service;

import java.util.List;
import java.util.Optional;

import com.cg.busBooking.dto.Booking;
import com.cg.busBooking.dto.Bus;

public interface BookingService 
{
	List<Booking> getAllBooking();
	Optional<Booking> getBookingById(Integer bookingId);
	Booking addNewBooking(Booking newBooking);
	Booking updateBookingById(Booking newBooking, Integer bookingId);
	void deleteBookingById(Integer bookingId);
}
