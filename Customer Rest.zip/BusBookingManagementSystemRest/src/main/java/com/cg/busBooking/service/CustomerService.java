package com.cg.busBooking.service;

import java.util.List;
import java.util.Optional;
import com.cg.busBooking.dto.Customer;

public interface CustomerService 
{
	List<Customer> getAllCustomer();
	Optional<Customer> getCustomerById(Integer customerId);
	Customer addNewCustomer(Customer newCustomer);
	Customer updateCustomerById(Customer newCustomer, Integer customerId);
	void deleteCustomerById(Integer customerId);
}
