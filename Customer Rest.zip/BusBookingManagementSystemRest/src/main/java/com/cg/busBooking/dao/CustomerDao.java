package com.cg.busBooking.dao;

import org.springframework.data.repository.CrudRepository;

import com.cg.busBooking.dto.Customer;
	public interface CustomerDao extends CrudRepository<Customer,Integer> 
	{
	}
	