package com.cg.busBooking.dto;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.auditing.DateTimeProvider;
@Entity
@Table(name = "bus")
public class Bus
{
	@Id
	@Column(name = "bus_id")
	private int busId;
	@Column(name = "source_station")
	private String sourceStation;
	@Column(name = "destination_station")
	private String destinationStation;
	@Column(name = "boarding_time")
	private String boardingTime;
	@Column(name = "drop_time")
	private String dropTime;
	@Column(name = "bus_type")
	private String busType;
	@Column(name = "total_seats")
	private int totalSeats;
	private int fare;
	@Column(name = "seat_no")
	private int seatNo;
	@Column(name = "seats_booked")
	private int seatsBooked;

	private Bus() {
		super();
	}

	public Bus(int busId, String sourceStation, String destinationStation, String boardingTime, String dropTime,
			String busType, int totalSeats, int fare, int seatNo, int seatsBooked) {
		super();
		this.busId = busId;
		this.sourceStation = sourceStation;
		this.destinationStation = destinationStation;
		this.boardingTime = boardingTime;
		this.dropTime = dropTime;
		this.busType = busType;
		this.totalSeats = totalSeats;
		this.fare = fare;
		seatNo = seatNo;
		this.seatsBooked = seatsBooked;
	}

	public int getBusId() 
	{
		return busId;
	}
	public void setBusId(int busId) 
	{
		this.busId = busId;
	}

	public String getSourceStation() 
	{
		return sourceStation;
	}
	public void setSourceStation(String sourceStation) 
	{
		this.sourceStation = sourceStation;
	}

	public String getDestinationStation() 
	{
		return destinationStation;
	}
	public void setDestinationStation(String destinationStation) 
	{
		this.destinationStation = destinationStation;
	}

	public String getBoardingTime() 
	{
		return boardingTime;
	}
	public void setBoardingTime(String boardingTime) 
	{
		this.boardingTime = boardingTime;
	}

	public String getDropTime() 
	{
		return dropTime;
	}
	public void setDropTime(String dropTime) 
	{
		this.dropTime = dropTime;
	}

	public String getBusType() 
	{
		return busType;
	}
	public void setBusType(String busType) 
	{
		this.busType = busType;
	}

	public int getTotalSeats() 
	{
		return totalSeats;
	}
	public void setTotalSeats(int totalSeats) 
	{
		this.totalSeats = totalSeats;
	}

	public int getFare() 
	{
		return fare;
	}
	public void setFare(int fare) 
	{
		this.fare = fare;
	}

	public int getSeatNo() 
	{
		return seatNo;
	}
	public void setSeatNo(int seatNo) 
	{
		seatNo = seatNo;
	}

	public int getSeatsBooked() 
	{
		return seatsBooked;
	}
	public void setSeatsBooked(int seatsBooked) 
	{
		this.seatsBooked = seatsBooked;
	}

	@Override
	public String toString() 
	{
		return "Bus [id=" + busId + ", sourceStation=" + sourceStation + ", destinationStation=" + destinationStation
				+ ", boardingTime=" + boardingTime + ", dropTime=" + dropTime + ", busType=" + busType + ", totalSeats="
				+ totalSeats + ", fare=" + fare + ", SeatNo=" + seatNo + ", seatsBooked=" + seatsBooked + "]";
	}

}
