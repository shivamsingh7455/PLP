package com.cg.busBooking.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.busBooking.dao.BusDao;
import com.cg.busBooking.dto.Bus;
import com.cg.busBooking.exception.NotFoundException;
@Service
public class BusServiceImpl implements BusService
{
	@Autowired
	private BusDao busDao;
	@Override
	public List<Bus> getAllBus() 
	{
		return (List<Bus>) busDao.findAll();
	}

	@Override
	public Optional<Bus> getBusById(Integer busId) 
	{
		return busDao.findById(busId);
	}

	@Override
	public Bus addNewBus(Bus newBus) 
	{
		return busDao.save(newBus);
	}

	@Override
	public Bus updateBusById(Bus newBus, Integer busId) 
	{
		if(busDao.existsById(busId))
		{
			return busDao.save(newBus);
		}
		throw new NotFoundException("Cant find id");
		
	}

	@Override
	public void deleteBusById(Integer busId) {
		busDao.deleteById(busId);		
	}

}
