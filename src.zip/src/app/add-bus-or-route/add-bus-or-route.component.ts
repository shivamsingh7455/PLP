
import { Component, OnInit } from '@angular/core';
import { Bus } from 'src/app/Bus';
import { BusService } from 'src/app/bus.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-bus-or-route',
  templateUrl: './add-bus-or-route.component.html',
  styleUrls: ['./add-bus-or-route.component.css']
})

export class AddBusOrRouteComponent implements OnInit {
  flag1: any;
  message: any;
  bus: Bus[] = [];
  constructor(private busSer: BusService, private router: Router) { }
  busDetails = new FormGroup({
    id: new FormControl('', Validators.required),
    sourceStation: new FormControl('', Validators.required),
    destinationStation: new FormControl('', Validators.required),
    boardingTime: new FormControl('', Validators.required),
    dropTime: new FormControl('', Validators.required),
    busType: new FormControl('', Validators.required),
    totalSeats: new FormControl('', Validators.required),
    fare: new FormControl('', Validators.required)
  })

  ngOnInit(): void {
    this.busSer.getBus();
  }

  busAdd() {
    let sourceStation = this.busDetails.get('sourceStation').value;
    let destinationStation = this.busDetails.get('destinationStation').value;
    let boardingTime = this.busDetails.get('boardingTime').value;
    let dropTime = this.busDetails.get('dropTime').value;
    let busType = this.busDetails.get('busType').value;
    let totalSeats = this.busDetails.get('totalSeats').value;
    let fare = this.busDetails.get('fare').value;
    let busId = this.busDetails.get('id').value;
    let SeatNo = null;
    let seatsBooked = null;
    for (var i = 0; i < this.busSer.busDb.length; i++) {
      if (this.busSer.busDb[i].id == busId) {
        this.message = "Bus with this Bus Id already exists!!!! Please choose another bus Id";
        break;
      }
    }
    if (busId == 0) {
      this.message = "Not a valid busId";
    }

    let tempAdd: Bus = new Bus(busId, sourceStation, destinationStation, boardingTime, dropTime, busType, totalSeats, fare, SeatNo, seatsBooked);
    this.busSer.addBus(tempAdd).subscribe(data => {
      console.log(data);
      this.message = "Bus Added Successfully. [Bus Id:" + busId + "]";
    });
    this.bus[0] = tempAdd;
  }
}
