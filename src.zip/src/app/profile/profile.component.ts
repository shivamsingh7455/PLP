import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';
import { Customer } from '../Customer';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  currentUser:Customer;

  constructor(private CustSer:CustomerService ,private router:Router) { }

  ngOnInit(): void {
    this.currentUser=this.CustSer.tempCustomer;
  }
  // moveToChangeName()
  // {
  //   this.router.navigateByUrl("/change-name");
  // }
  // moveToChangePassword()
  // {
  //   this.router.navigateByUrl("/change-password");
  // }
  // moveToChangeAge()
  // {
  //   this.router.navigateByUrl("/change-age");
  // }
  // moveToChangePhoneNumber()
  // {
  //   this.router.navigateByUrl("/change-phone-number");
  // }
}
