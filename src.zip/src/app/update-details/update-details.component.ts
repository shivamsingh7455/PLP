import { Component, OnInit } from '@angular/core';
import{Router} from '@angular/router';

@Component({
  selector: 'app-update-details',
  templateUrl: './update-details.component.html',
  styleUrls: ['./update-details.component.css']
})
export class UpdateDetailsComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  moveToUpdateBoardingTime(){
    this.router.navigate(['update-boarding-time']);
  }
  moveToUpdateDropTime(){
    this.router.navigate(['update-drop-time']);
  }
 moveToUpdateSourceStation(){
   this.router.navigate(['update-source-station']);
 }
 moveToUpdateDestinationStation(){
   this.router.navigate(['update-destination-station']);
 }
 moveToUpdateBusType(){
   this.router.navigate(['/update-bus-type']);
 }
 moveToUpdateTotalSeats(){
   this.router.navigate(['update-seats']);
 }
 moveToUpdateFare(){
   this.router.navigate(['update-fare']);
 }
}
