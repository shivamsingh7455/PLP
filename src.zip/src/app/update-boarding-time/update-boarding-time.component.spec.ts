import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateBoardingTimeComponent } from './update-boarding-time.component';

describe('UpdateBoardingTimeComponent', () => {
  let component: UpdateBoardingTimeComponent;
  let fixture: ComponentFixture<UpdateBoardingTimeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateBoardingTimeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateBoardingTimeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
