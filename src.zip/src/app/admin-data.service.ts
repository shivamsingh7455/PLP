import { BookingClass } from './BookingClass';
import { Observable } from 'rxjs';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BusClass } from './BusClass';

@Injectable({
  providedIn: 'root'
})
export class AdminDataService {
  private options = { headers: new HttpHeaders().set('Content-Type', 'application/json') };
  constructor(private httpClient: HttpClient) { }

  login(email: string, password: string): Observable<boolean> {
    return this.httpClient.get<boolean>("http://localhost:8080/api/login/" + email + '/' + password, this.options);
  }


  getBus(): Observable<BusClass[]> {
    return this.httpClient.get<BusClass[]>("http://localhost:8080/api/bus", this.options);
  }

  addBus(bus: BusClass): Observable<BusClass> {
    return this.httpClient.post<BusClass>("http://localhost:8080/api/addBus", JSON.stringify(bus), this.options);
  }

  deleteBus(id: any): Observable<BusClass> {
    return this.httpClient.delete<BusClass>("http://localhost:8080/api/delete" + id, this.options);
  }

  getBooking(): Observable<BookingClass> {
    return this.httpClient.get<BookingClass>("http://localhost:8080/api/booking", this.options);
  }

  addBooking(booking: BookingClass) {
    return this.httpClient.post('http://localhost:8080/api/booking', booking);
  }

  getBookingById(id: any): Observable<BookingClass[]> {
    return this.httpClient.get<BookingClass[]>("http://localhost:8080/api/booking/bus/" + id, this.options);
  }

  deleteBooking(id: any): Observable<number[]> {
    return this.httpClient.delete<number[]>("http://localhost:8080/api/delete/" + id, this.options);
  }

  updateBooking(id: any, booking: BookingClass) {
    return this.httpClient.put('http://localhost:8080/api/booking/' + id, booking);
  }

  updateBusBySourceStation(id: any, sourceStation: any) {
    return this.httpClient.put('http://localhost:8080/api/update/sourceStation/' + id + '/' + sourceStation, this.options);
  }

  updateBusByDestinationStation(id: any, destinationStation: any) {
    return this.httpClient.put('http://localhost:8080/api/update/destinationStation/' + id + '/' + destinationStation, this.options);
  }

  updateBusByBoardingTime(id: any, boardingTime: any) {
    return this.httpClient.put('http://localhost:8080/api/update/boardingTime/' + id + '/' + boardingTime, this.options);
  }

  updateBusByDropTime(id: any, dropTime: any) {
    return this.httpClient.put('http://localhost:8080/api/update/dropTime/' + id + '/' + dropTime, this.options);
  }

  updateBusByBusType(id: any, busType: any) {
    return this.httpClient.put('http://localhost:8080/api/update/busType/' + id + '/' + busType, this.options);
  }

  updateBusByTotalSeats(id: any, totalSeats: any) {
    return this.httpClient.put('http://localhost:8080/api/update/totalSeats/' + id + '/' + totalSeats, this.options);
  }

  updateBusByFare(id: any, fare: any) {
    return this.httpClient.put('http://localhost:8080/api/update/fare/' + id + '/' + fare, this.options);
  }
}
