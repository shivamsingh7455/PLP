import { Component, OnInit } from '@angular/core';
import { BookingService } from '../booking.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import { Booking } from '../Booking';

@Component({
  selector: 'app-feedback-rating',
  templateUrl: './feedback-rating.component.html',
  styleUrls: ['./feedback-rating.component.css']
})
export class FeedbackRatingComponent implements OnInit {
  flag1:any;
  tempBooking:Booking;
  constructor(private bookSer:BookingService,private router:Router) { }
  feedback = new FormGroup({
    bookingId: new FormControl(''),
    feedback: new FormControl(''),
    rating: new FormControl('')
  })
    ngOnInit(): void 
    {
      // this.bookSer.getBooking();
    }
  feedbackRating()
  {
  if(this.feedback.valid)
  {
  let bookingId = this.feedback.get('bookingId').value;
  let feedback=this.feedback.get('feedback').value;
  let rating=this.feedback.get('rating').value;
    for(let i=0;i<this.bookSer.bookingDb.length;i++) 
    {
      if (this.bookSer.bookingDb[i].id==bookingId)
      {     
            this.bookSer.bookingDb[i].feedBack=feedback;
            this.bookSer.bookingDb[i].rating=rating;
            this.tempBooking=this.bookSer.bookingDb[i];
            this.bookSer.updateBooking(this.bookSer.bookingDb[i].id,this.tempBooking).subscribe(data=>{console.log(data)});
            this.bookSer.flag=true;  
      }     
    }
    if (this.bookSer.flag==true) 
    {
      this.flag1=true;
    }
  }
  }

}
