import { AdminDataService } from './../admin-data.service';
import { BusClass } from './../BusClass';
import { Component, OnInit } from '@angular/core';
import { Bus } from 'src/app/Bus';
import { Router } from '@angular/router';
import{BusService} from 'src/app/bus.service';
import { FormGroup,FormControl } from '@angular/forms';

@Component({
  selector: 'app-update-fare',
  templateUrl: './update-fare.component.html',
  styleUrls: ['./update-fare.component.css']
})
export class UpdateFareComponent implements OnInit {
  flag1:boolean;
  tempBus:Bus;
  bus:BusClass[];

  constructor(private adminSer:AdminDataService,router:Router) { }
  updateBusFare=new FormGroup({
    busId:new FormControl,
    fare:new FormControl

  })
  
  ngOnInit(): void {
    this.adminSer.getBus().subscribe(data => this.bus=data);
  }
  updateFare(){
    let busId=this.updateBusFare.get('busId').value;
    let fare=this.updateBusFare.get('fare').value;
    for(let i=0;i<this.bus.length;i++)
    {
        if(this.bus[i].busId==busId)
        {
         
          this.adminSer.updateBusByFare(busId,fare).subscribe(data=>(console.log(data)));
          this.flag1=true;

        }
    }

  }

}
