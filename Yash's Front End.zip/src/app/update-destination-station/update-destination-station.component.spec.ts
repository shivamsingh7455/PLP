import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateDestinationStationComponent } from './update-destination-station.component';

describe('UpdateDestinationStationComponent', () => {
  let component: UpdateDestinationStationComponent;
  let fixture: ComponentFixture<UpdateDestinationStationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateDestinationStationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateDestinationStationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
