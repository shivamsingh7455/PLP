package com.cg.obtrs.service;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cg.obtrs.dao.BusDao;
import com.cg.obtrs.dto.BookingDto;
import com.cg.obtrs.dto.BusDto;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class AdminServiceImpl implements AdminService {

	final static Logger logger = Logger.getLogger(AdminServiceImpl.class);

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private BusDao busDao;

	@Override
	@HystrixCommand(fallbackMethod = "busByBusIdFallbackMethod")
	public ResponseEntity<BusDto> getBusByBusId(Integer busId) {

		BusDto bus = restTemplate.getForObject("http://localhost:8082/bus/busbyid/" + busId, BusDto.class);
		ResponseEntity<BusDto> response = new ResponseEntity<>(bus, HttpStatus.OK);
		logger.info(response);
		return response;
	}

	@Override
	// @HystrixCommand(fallbackMethod = "bookingByBusIdFallbackMethod")
	public ResponseEntity<List<BookingDto>> getBookingbyBusId(Integer busId) {
		List<BookingDto> bookingList = restTemplate
				.getForObject("http://localhost:8081/booking/bookingbyBusId/" + busId, List.class);
		ResponseEntity<List<BookingDto>> response = new ResponseEntity<>(bookingList, HttpStatus.OK);
		return response;
	}

	@Override
	public ResponseEntity<List<BusDto>> getAllBus() {
		List<BusDto> busList = restTemplate.getForObject("http://localhost:8082/bus/buses", List.class);
		ResponseEntity<List<BusDto>> response = new ResponseEntity<>(busList, HttpStatus.OK);
		return response;
	}

	public ResponseEntity<BusDto> busByBusIdFallbackMethod(Integer busId) {
		BusDto bus = new BusDto(BigInteger.valueOf(0), "", "", LocalDateTime.of(0, 0, 0, 0, 0, 0),
				LocalDateTime.of(0, 0, 0, 0, 0, 0), "", 0, 0.0f, 0);
		ResponseEntity<BusDto> response = new ResponseEntity<>(bus, HttpStatus.INTERNAL_SERVER_ERROR);
		return response;
	}

	@Override
	public ResponseEntity<BusDto> addBus(BusDto bus) {
		HttpEntity<BusDto> requestEntity = new HttpEntity<BusDto>(bus);
		ResponseEntity<BusDto> response = restTemplate.exchange("http://localhost:8082/bus/new", HttpMethod.POST,
				requestEntity, BusDto.class);
		return response;
	}

	@Override
	public boolean cancelBooking(BigInteger bookingId) {
		restTemplate.delete("http://localhost:8081/booking/delete/" + bookingId);
		return true;
	}

}
