package com.cg.obtrs.dto;

import java.math.BigInteger;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

/*
 * DTO is used for transferring data across different layers of 
 * the application 
 * */
public class BookingDto {

	// Booking attributes
	private BigInteger bookingId;
	private BigInteger busId;
	private float totalFare;
	private Date bookingDate;
	// Passenger attributes
	private List<String> passengerNames = new ArrayList<>();
	private Integer seatsBooked;
	private String seatNo;
	// Customer attributes
	private String customerEmail;
	private int customerRating;
	private String customerFeedback;

	public BookingDto() {
		super();
	}

	public BookingDto(BigInteger busId, List<String> passengerNames, Integer seatsBooked, float totalFare,
			BigInteger bookingId, String seatNo, Date bookingDate, String customerEmail, int customerRating,
			String customerFeedback) {
		super();
		this.busId = busId;
		this.passengerNames = passengerNames;
		this.seatsBooked = seatsBooked;
		this.totalFare = totalFare;
		this.bookingId = bookingId;
		this.seatNo = seatNo;
		this.bookingDate = bookingDate;
		this.customerEmail = customerEmail;
		this.customerRating = customerRating;
		this.customerFeedback = customerFeedback;
	}

	public Integer getSeatsBooked() {
		return seatsBooked;
	}

	public void setSeatsBooked(Integer seatsBooked) {
		this.seatsBooked = seatsBooked;
	}

	public List<String> getPassengerNames() {
		return passengerNames;
	}

	public void setPassengerNames(List<String> passengerNames) {
		this.passengerNames = passengerNames;
	}

	public float getTotalFare() {
		return totalFare;
	}

	public void setTotalFare(float totalFare) {
		this.totalFare = totalFare;
	}

	public BigInteger getBookingId() {
		return bookingId;
	}

	public void setBookingId(BigInteger bookingId) {
		this.bookingId = bookingId;
	}

	public BigInteger getBusId() {
		return busId;
	}

	public void setBusId(BigInteger busId) {
		this.busId = busId;
	}

	public String getSeatNo() {
		return seatNo;
	}

	public void setSeatNo(String seatNo) {
		this.seatNo = seatNo;
	}

	public Date getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(Date bookingDate) {
		this.bookingDate = bookingDate;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public int getCustomerRating() {
		return customerRating;
	}

	public void setCustomerRating(int customerRating) {
		this.customerRating = customerRating;
	}

	public String getCustomerFeedback() {
		return customerFeedback;
	}

	public void setCustomerFeedback(String customerFeedback) {
		this.customerFeedback = customerFeedback;
	}

	@Override
	public String toString() {
		return "BookingDTO [busId=" + busId + ", passengerNames=" + passengerNames + ", seatsBooked=" + seatsBooked
				+ ", totalFare=" + totalFare + "]";
	}

}
