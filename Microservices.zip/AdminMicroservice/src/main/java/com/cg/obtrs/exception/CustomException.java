package com.cg.obtrs.exception;

public class CustomException extends RuntimeException {

	public CustomException(String msg) {
		super(msg);

	}

}
