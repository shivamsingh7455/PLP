package com.cg.obtrs.controller;

import java.math.BigInteger;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.obtrs.service.AdminService;
import com.cg.obtrs.dto.BookingDto;
import com.cg.obtrs.dto.BusDto;


/* @RestController tells Spring that this is the Handler class and contains handler methods. Basically does combined job of @Controller and @ResponseBody
 * @RequestMapping annotation is used to map the web requests to specified
 * handler classes or methods
 * @CrossOrigin annotation is used to handle Cross-Origin-Resource-Sharing */
@RestController
@RequestMapping("/admin")
@CrossOrigin("*")
public class AdminController {
	
	final static Logger logger = Logger.getLogger(AdminController.class);
	
	@Autowired
	AdminService adminService;
	
	// Method to get bus details as per bus Id as a parameter
	
	@GetMapping("/bus/{busId}")
	public ResponseEntity<BusDto> getBusByBusId(@PathVariable Integer busId) {
		logger.info(adminService.getBusByBusId(busId));
		return adminService.getBusByBusId(busId);
	}
	
	// Method to get all bus details.
	@GetMapping("/buses")
	public ResponseEntity<List<BusDto>> getAllBus() {
		logger.info(adminService.getAllBus());
		return adminService.getAllBus();
	}

	// Method to get booking details as per bus Id as a parameter
	@GetMapping("/booking/bus/{busId}")
	public ResponseEntity<List<BookingDto>> getBookingbyBusId(@PathVariable Integer busId) {
		logger.info(adminService.getBookingbyBusId(busId));
		return adminService.getBookingbyBusId(busId);
	}
	
	// Method to add new bus details
	@CrossOrigin("*")
	@PostMapping("/addBus")
	public ResponseEntity<BusDto> addNewBus(@RequestBody BusDto bus) {
		return adminService.addBus(bus);
	}
	
	//Method to cancel any booking with booking Id as a parameter
	@DeleteMapping("/delete/{bookingId}")
	public boolean cancelBooking(@PathVariable BigInteger bookingId) {
		logger.info("BOOKING REMOVED WITH THE BOOKING ID = " + bookingId);
		return adminService.cancelBooking(bookingId);
	

		
	}
}
