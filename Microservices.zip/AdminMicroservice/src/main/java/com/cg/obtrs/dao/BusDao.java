package com.cg.obtrs.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.cg.obtrs.entities.BusEntity;

/*
 * DAO design pattern is a way to reduce coupling between Business logic and
 * Persistence logic. 
 */
@CrossOrigin("*")
public interface BusDao extends JpaRepository<BusEntity, Integer> {

}
