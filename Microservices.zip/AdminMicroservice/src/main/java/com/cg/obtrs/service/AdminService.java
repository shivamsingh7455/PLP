package com.cg.obtrs.service;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cg.obtrs.dto.BookingDto;
import com.cg.obtrs.dto.BusDto;
import com.cg.obtrs.entities.BookingEntity;
import com.cg.obtrs.entities.BusEntity;
import com.cg.obtrs.exception.CustomException;

@Service
public interface AdminService {

	ResponseEntity<BusDto> getBusByBusId(Integer busId);

	ResponseEntity<List<BookingDto>> getBookingbyBusId(Integer busId);

	ResponseEntity<List<BusDto>> getAllBus();

	ResponseEntity<BusDto> addBus(BusDto bus) throws CustomException;

	boolean cancelBooking(BigInteger bookingId) throws CustomException;


}
