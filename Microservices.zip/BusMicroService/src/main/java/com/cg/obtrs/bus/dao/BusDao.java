package com.cg.obtrs.bus.dao;

import java.math.BigInteger;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.cg.obtrs.bus.entities.BusEntity;
/*
 * DAO design pattern is a way to reduce coupling between Business logic and
 * Persistence logic. 
 */
@CrossOrigin("http://localhost:4200")
public interface BusDao extends JpaRepository<BusEntity, BigInteger>{

	@Query(value = "Select * from Bus where source_station = ?1 AND destination_station =?2", nativeQuery = true)
	List<BusEntity> searchBus(String sourceStation, String destinationStation);

	@Query(value = "Select DISTINCT source_station from Bus", nativeQuery = true)
	List<String> findAllSourceStation();
	
	@Query(value = "Select DISTINCT destination_station from Bus", nativeQuery = true)
	List<String> findAllDestinationStation();
    
}
