package com.cg.obtrs.bus.exception;

public class InvalidBusIdException extends RuntimeException {
	public InvalidBusIdException(String msg) {
		super(msg);
	}
}
