package com.cg.obtrs.bus.services;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.obtrs.bus.dao.BusDao;
import com.cg.obtrs.bus.entities.BusEntity;
import com.cg.obtrs.bus.exception.InvalidArgumentException;
import com.cg.obtrs.bus.exception.InvalidBusIdException;

@Service
public class BusServiceImpl implements BusService {

	@Autowired
	BusDao busDao;
	final static Logger logger = Logger.getLogger(BusServiceImpl.class);

	@Override
	public BusEntity getBusById(BigInteger busId) throws InvalidBusIdException {
		Optional<BusEntity> optional = busDao.findById(busId);
		if (optional.isPresent()) {
			BusEntity bus = optional.get();
			return bus;
		} else {
			logger.error("BUS NOT FOUND WITH THE BUS ID = " + busId);
			throw new InvalidBusIdException("Sorry, Bus Not Found");
		}
	}

	@Override
	public BusEntity updateBus(BusEntity bus) throws InvalidArgumentException {
		if (bus == null) {
			throw new InvalidArgumentException("Bus can't be null");
		}
		return busDao.save(bus);
	}

	@Override
	public List<BusEntity> searchBus(String sourceStation, String destinationStation) {
		return busDao.searchBus(sourceStation, destinationStation);
	}

	@Override
	public List<String> findAllSourceStation() {
		return busDao.findAllSourceStation();
	}

	@Override
	public List<String> findAllDestinationStation() {
		return busDao.findAllDestinationStation();
	}

	@Override
	public List<BusEntity> getAllBus() {
		return busDao.findAll();
	}

	@Override
	public boolean deleteBus(BigInteger busId) throws InvalidBusIdException {
		Optional<BusEntity> optional = busDao.findById(busId);
		if (optional.isPresent()) {
			busDao.deleteById(busId);
			return true;
		} else {
			logger.error("BUS NOT FOUND WITH THE BUS ID = " + busId);
			throw new InvalidBusIdException("Sorry, Bus Not Found");
		}
	}

	@Override
	public BusEntity addBus(BusEntity bus) throws InvalidArgumentException {
		BigInteger busId = bus.getBusId();
		if(busId.equals(null)) {
			logger.error("BusId cannot be null");
			throw new InvalidArgumentException("Bus Id cannot be null");
		}
		List<BusEntity> busDetails = (List<BusEntity>) busDao.findAll();
		for (int i = 0; i < busDetails.size(); i++) {
			if (busDetails.get(i).getBusId().equals(busId)) {
				logger.error("Bus Id already Exist");
				throw new InvalidArgumentException("Bus with this Bus Id already exist");
			}
		}
		logger.info("New Bus added successfully with BusId: " + busId);
		return busDao.save(bus);
	}

}
