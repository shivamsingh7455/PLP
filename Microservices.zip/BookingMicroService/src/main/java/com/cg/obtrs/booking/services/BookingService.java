package com.cg.obtrs.booking.services;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.cg.obtrs.booking.entities.BookingEntity;
import com.cg.obtrs.booking.exception.InvalidArgumentException;
import com.cg.obtrs.booking.exception.InvalidBookingIdException;

public interface BookingService {
	List<BookingEntity> getAllBooking();

	BookingEntity getBookingById(BigInteger bookingId) throws InvalidBookingIdException;

	BookingEntity addBooking(BookingEntity entity) throws InvalidArgumentException;

	boolean cancelBooking(BigInteger bookingId) throws InvalidBookingIdException;

	BookingEntity modifyBooking(BookingEntity booking) throws InvalidBookingIdException;

	List<BookingEntity> getBookingByBusId(BigInteger busId);
}
