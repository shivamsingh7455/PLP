package com.cg.obtrs.booking.controller;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cg.obtrs.booking.dto.BookingDto;
import com.cg.obtrs.booking.entities.BookingEntity;
import com.cg.obtrs.booking.entities.BusEntity;
import com.cg.obtrs.booking.exception.InvalidArgumentException;
import com.cg.obtrs.booking.exception.InvalidBookingIdException;
import com.cg.obtrs.booking.services.BookingService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

/* @RestController tells Spring that this is the Handler class and contains handler methods. Basically does combined job of @Controller and @ResponseBody
 * @RequestMapping annotation is used to map the web requests to specified 
 * handler classes or methods
 * @CrossOrigin annotation is used to handle Cross-Origin-Resource-Sharing */
@RestController
@RequestMapping("/booking")
@CrossOrigin("http://localhost:4200")
public class BookingController {

	@Autowired
	private BookingService bookingService;

	@Autowired
	private RestTemplate restTemplate;

	final static Logger logger = Logger.getLogger(BookingController.class);

	/*
	 * Method that consumes Bus MicroService to get all the source station.
	 * 
	 * @HystrixCommand annotation to implement CircuitBreaker and call the fallback
	 * methods is case of failure of interacting MicroService
	 */
	@HystrixCommand(fallbackMethod = "getFallBackSourceStation")
	@GetMapping("/source")
	public ResponseEntity<List<String>> getAllSourceStation() {
		String url = "http://BUS-INFO-SERVICE/bus/allsource";
		List<String> source = restTemplate.getForObject(url, List.class);
		ResponseEntity<List<String>> response = new ResponseEntity<>(source, HttpStatus.OK);
		return response;
	}

	/*
	 * Fallback method in case of failure to getAllSourceStation from
	 * BusMicroservice
	 */
	public ResponseEntity<List<String>> getFallBackSourceStation() {
		List<String> source = new ArrayList<String>(Arrays.asList("No Source"));
		ResponseEntity<List<String>> response = new ResponseEntity<>(source, HttpStatus.OK);
		return response;
	}

	// Method to consume Bus MicroService to get all the destination station.
	@HystrixCommand(fallbackMethod = "getFallBackDestinationStation")
	@GetMapping("/destination")
	public ResponseEntity<List<String>> getAllDestinationStation() {
		String url = "http://BUS-INFO-SERVICE/bus/alldestination";
		List<String> source = restTemplate.getForObject(url, List.class);
		ResponseEntity<List<String>> response = new ResponseEntity<>(source, HttpStatus.OK);
		return response;
	}

	/*
	 * FallBack method for the failure of getAllDestinationStation from
	 * BusMicroservice
	 */
	public ResponseEntity<List<String>> getFallBackDestinationStation() {
		List<String> source = new ArrayList<String>(Arrays.asList("No destination"));
		ResponseEntity<List<String>> response = new ResponseEntity<>(source, HttpStatus.OK);
		return response;
	}

	/*
	 * Method to consume Bus MicroService to search for a bus based on source and
	 * destination
	 */
	@HystrixCommand(fallbackMethod = "getFallBackSearchBus")
	@GetMapping("/searchbus/{sourceStation}+{destinationStation}")
	public ResponseEntity<List<BusEntity>> searchForBus(@PathVariable String sourceStation,
			@PathVariable String destinationStation) {
		String url = "http://BUS-INFO-SERVICE/bus/searchbus/" + sourceStation + "+" + destinationStation;
		List<BusEntity> bus = restTemplate.getForObject(url, List.class);
		ResponseEntity<List<BusEntity>> response = new ResponseEntity<>(bus, HttpStatus.OK);
		return response;
	}

	// FallBack method in case of the failure of searchBus from BusMicroservice
	public ResponseEntity<List<BusEntity>> getFallBackSearchBus(@PathVariable String sourceStation,
			@PathVariable String destinationStation) {
		List<BusEntity> busList = new ArrayList<>();
		List<BusEntity> bus = getFallBackBusObject();
		for (BusEntity busEntity : bus) {
			if (busEntity.getSourceStation().equalsIgnoreCase(sourceStation)
					&& busEntity.getDestinationStation().equalsIgnoreCase(destinationStation)) {
				busList.add(busEntity);
			}
		}
		ResponseEntity<List<BusEntity>> response = new ResponseEntity<>(busList, HttpStatus.OK);
		return response;
	}

	// Method to consume Bus MicroService to get all currently operating buses.
	@HystrixCommand(fallbackMethod = "getFallBackAllBus")
	@GetMapping("/buses")
	public ResponseEntity<List<BusEntity>> getAllBuses() {
		String url = "http://BUS-INFO-SERVICE/bus/buses";
		List<BusEntity> bus = restTemplate.getForObject(url, List.class);
		ResponseEntity<List<BusEntity>> response = new ResponseEntity<>(bus, HttpStatus.OK);
		return response;
	}

	// FallBack method for the failure of searchBus from BusMicroservice
	public ResponseEntity<List<BusEntity>> getFallBackAllBus() {
		List<BusEntity> bus = getFallBackBusObject();
		ResponseEntity<List<BusEntity>> response = new ResponseEntity<>(bus, HttpStatus.OK);
		return response;
	}

	/*
	 * Method to consume Bus MicroService that fetches bus using bus id.
	 * 
	 * @param busId
	 */
	@HystrixCommand(fallbackMethod = "getFallBackBus")
	@GetMapping("/busbyid/{busId}")
	public ResponseEntity<BusEntity> getBus(@PathVariable BigInteger busId) {
		String url = "http://BUS-INFO-SERVICE/bus/busbyid/" + busId;
		BusEntity bus = restTemplate.getForObject(url, BusEntity.class);
		ResponseEntity<BusEntity> response = new ResponseEntity<>(bus, HttpStatus.OK);
		return response;
	}

	/*
	 * FallBack method in case of failure of getBus from BusMicroservice
	 * 
	 * @param busId
	 */
	public ResponseEntity<BusEntity> getFallBackBus(@PathVariable BigInteger busId) throws InvalidBookingIdException {
		ResponseEntity<BusEntity> response = null;
		boolean flag = false;
		List<BusEntity> bus = getFallBackBusObject();
		for (BusEntity busEntity : bus) {
			if (busEntity.getBusId() == busId) {
				response = new ResponseEntity<>(busEntity, HttpStatus.OK);
				flag = true;
				break;
			}
		}
		if (flag == true) {
			return response;
		} else
			throw new InvalidBookingIdException("Sorry, No Bus Available");
	}

	// Consuming Bus MicroService to update bus when done a new booking is added
	@PutMapping("/updatebus")
	public ResponseEntity<BusEntity> updateBus(@RequestBody BusEntity entity) {
		String url = "http://BUS-INFO-SERVICE/bus/update";
		HttpEntity<BusEntity> requestEntity = new HttpEntity<>(entity);
		ResponseEntity<BusEntity> response = restTemplate.exchange(url, HttpMethod.PUT, requestEntity, BusEntity.class);
		return response;
	}

	/*
	 * Method to add a new Booking
	 * 
	 * @param bookingDto
	 */
	@PostMapping("/new")
	public ResponseEntity<BookingDto> addNewBooking(@RequestBody BookingDto bookingDto) {
		BookingEntity booking = new BookingEntity();
		booking.setBookingId(bookingDto.getBookingId());
		booking.setBookingDate(bookingDto.getBookingDate());
		booking.setBusId(bookingDto.getBusId());
		booking.setTotalFare(bookingDto.getTotalFare());
		booking.setSeatsBooked(bookingDto.getSeatsBooked());
		booking.setSeatNo(bookingDto.getSeatNo());
		booking.setPassengerNames(bookingDto.getPassengerNames());
		booking.setCustomerEmail(bookingDto.getCustomerEmail());
		booking.setCustomerRating(bookingDto.getCustomerRating());
		bookingService.addBooking(booking);
		ResponseEntity<BookingDto> response = new ResponseEntity<>(bookingDto, HttpStatus.OK);
		logger.info("A NEW BOOKING ADDED WITH THE BOOKING ID = " + bookingDto.getBookingId());
		return response;
	}

	/*
	 * Method to fetch booking details using booking id.
	 * 
	 * @param bookingId
	 */
	@GetMapping("/bookingbyid/{bookingId}")
	public ResponseEntity<BookingEntity> getBookingById(@PathVariable BigInteger bookingId) {
		BookingEntity booking = bookingService.getBookingById(bookingId);
		ResponseEntity<BookingEntity> response = new ResponseEntity<>(booking, HttpStatus.OK);
		return response;
	}

	/*
	 * Method to fetch all the bookings.
	 * 
	 * return a list of booking as response
	 */
	@GetMapping("/booking")
	public ResponseEntity<List<BookingEntity>> getAllBooking() {
		List<BookingEntity> booking = bookingService.getAllBooking();
		ResponseEntity<List<BookingEntity>> response = new ResponseEntity<>(booking, HttpStatus.OK);
		return response;
	}

	// Method to update the booking
	@PutMapping("/update")
	public ResponseEntity<BookingEntity> modifyBooking(@RequestBody BookingEntity booking) {
		BookingEntity bookingEntity = bookingService.modifyBooking(booking);
		ResponseEntity<BookingEntity> response = new ResponseEntity<>(bookingEntity, HttpStatus.OK);
		logger.info("BOOKING WITH THE BOOKING ID = " + booking.getBookingId() + " MODIFIED.");
		return response;

	}
	
	@GetMapping("/bookingbyBusId/{busId}")
	public ResponseEntity<List<BookingEntity>> getBookingByBusId(@PathVariable BigInteger busId) {
		List<BookingEntity> booking = bookingService.getBookingByBusId(busId);
		ResponseEntity<List<BookingEntity>> response = new ResponseEntity<>(booking, HttpStatus.OK);
		return response;
	}

	/*
	 * Method to cancel a customer's booking return true if cancellation is
	 * successful.
	 * 
	 */
	@DeleteMapping("/delete/{bookingId}")
	public boolean cancelBooking(@PathVariable BigInteger bookingId) {
		bookingService.cancelBooking(bookingId);
		logger.info("BOOKING REMOVED WITH THE BOOKING ID = " + bookingId);
		return true;
	}

	// Method to return a busObject used in fallback methods in case of failure of
	// Bus MicroService.
	public List<BusEntity> getFallBackBusObject() {
		List<BusEntity> bus = new ArrayList<>();
		BusEntity busEntity = new BusEntity();
		BigInteger bigInteger = BigInteger.valueOf(0);
		busEntity.setBusId(bigInteger);
		busEntity.setBusType("No Type");
		busEntity.setSourceStation("No Source");
		busEntity.setDestinationStation("No Destination");
		LocalDateTime boardingTime = LocalDateTime.of(0000, 1, 1, 0, 0, 0);
		busEntity.setBoardingTime(boardingTime);
		LocalDateTime dropTime = LocalDateTime.of(0000, 1, 1, 0, 0, 0);
		busEntity.setDropTime(dropTime);
		busEntity.setFare(0f);
		busEntity.setSeatsBooked(0);
		busEntity.setTotalSeats(0);
		bus.add(busEntity);
		return bus;
	}

	/*
	 * Handle Invalid BookingId Exception
	 * 
	 * @param ex
	 */
	@ExceptionHandler(InvalidBookingIdException.class)
	public ResponseEntity<String> handleBookingNotFound(InvalidBookingIdException ex) {
		logger.error("INVALID BOOKING ID!!!", ex);
		String msg = ex.getMessage();
		ResponseEntity<String> response = new ResponseEntity<>(msg, HttpStatus.NOT_FOUND);
		return response;
	}

	/*
	 * Handle Booking not found Exception
	 * 
	 * @param ex
	 */
	@ExceptionHandler(InvalidArgumentException.class)
	public ResponseEntity<String> handleBookingNotFound(InvalidArgumentException ex) {
		logger.error("BOOKING NOT FOUND!!!", ex);
		String msg = ex.getMessage();
		ResponseEntity<String> response = new ResponseEntity<>(msg, HttpStatus.NOT_FOUND);
		return response;
	}

	/*
	 * Blanket Exception Handler
	 * 
	 * @param ex
	 */
	@ExceptionHandler(Throwable.class)
	public ResponseEntity<String> handleAll(Throwable ex) {
		logger.error("Something went wrong", ex);
		String msg = ex.getMessage();
		ResponseEntity<String> response = new ResponseEntity<>(msg, HttpStatus.INTERNAL_SERVER_ERROR);
		return response;
	}
}
