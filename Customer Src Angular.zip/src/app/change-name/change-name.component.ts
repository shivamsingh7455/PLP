import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-change-name',
  templateUrl: './change-name.component.html',
  styleUrls: ['./change-name.component.css']
})
export class ChangeNameComponent implements OnInit {
  flag1:boolean;
  tempCustomer:any;
  constructor(private custSer:CustomerService,private router:Router) { }
  changename = new FormGroup({
    customerEmail: new FormControl('',Validators.required),
    password: new FormControl('',Validators.required),
    name: new FormControl('',Validators.required)
  })
    ngOnInit(): void 
    {
      this.custSer.getCustomer();
    }
  changeName()
  {
    this.flag1=false;
 
  let customerEmail = this.changename.get('customerEmail').value;
  let password=this.changename.get('password').value;
  let name=this.changename.get('name').value;
      if ((this.custSer.tempCustomer.customerEmail==customerEmail)&&(this.custSer.tempCustomer.customerPassword==password))
      {
            this.custSer.tempCustomer.customerName=name;
            this.tempCustomer=this.custSer.tempCustomer;
            this.custSer.updateCustomer(this.custSer.tempCustomer.customerId,this.tempCustomer).subscribe(data=>{console.log(data)});
            this.custSer.flag=true; 
            this.flag1=true;
            this.router.navigateByUrl("/profile");
      }     
  }
}
