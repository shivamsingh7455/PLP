import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Router } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Customer } from '../Customer';

@Component({
  selector: 'app-change-phone-number',
  templateUrl: './change-phone-number.component.html',
  styleUrls: ['./change-phone-number.component.css']
})
export class ChangePhoneNumberComponent implements OnInit {
  flag1:boolean;

  constructor(private custSer:CustomerService,private router:Router) { }
  changephonenumber = new FormGroup({
    customerEmail: new FormControl('',Validators.required),
    password: new FormControl('',Validators.required),
    phoneNumber: new FormControl('',Validators.required)
  })
    ngOnInit(): void 
    {
      this.custSer.getCustomer();
    }
  changePhoneNumber()
  {
    this.flag1=false;
  if(this.changephonenumber.valid)
  {
  let customerEmail = this.changephonenumber.get('customerEmail').value;
  let password=this.changephonenumber.get('password').value;
  let phoneNumber=this.changephonenumber.get('phoneNumber').value;
   
      if (this.custSer.tempCustomer.customerEmail == customerEmail)
      {     
        if(this.custSer.tempCustomer.customerPassword==password)
        {
            this.custSer.tempCustomer.customerPhoneNumber=phoneNumber;
            let tempCustomer:Customer=this.custSer.tempCustomer;
            this.custSer.updateCustomer(this.custSer.tempCustomer.customerId,tempCustomer).subscribe(data=>{console.log(data)});
            this.custSer.flag=true;
            this.flag1=true;
            this.router.navigateByUrl("/profile");
        }
      }     
  }
  }
}
