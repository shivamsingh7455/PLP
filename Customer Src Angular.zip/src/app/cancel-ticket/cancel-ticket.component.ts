import { Component, OnInit } from '@angular/core';
import { Booking } from '../Booking';
import { BookingService } from '../booking.service';
import { Router } from '@angular/router';
import { BusService } from '../bus.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-cancel-ticket',
  templateUrl: './cancel-ticket.component.html',
  styleUrls: ['./cancel-ticket.component.css']
})
export class CancelTicketComponent implements OnInit {
  flag1:any;
  constructor(private bookingSer:BookingService,private router:Router,private custSer:CustomerService) { }
  cancelticket = new FormGroup({
    bookingId: new FormControl('',Validators.required)
  })
    ngOnInit(): void 
    {
    }
  cancelTicket()
  {
    if(this.cancelticket.valid)
    {
      this.flag1=false;
    let bookingId=this.cancelticket.get('bookingId').value;
    let k=0;
    for(let i=0;i<this.bookingSer.bookingDb.length;i++) 
    {
      if (this.bookingSer.bookingDb[i].bookingId==bookingId&&this.custSer.tempCustomer.customerId==this.bookingSer.bookingDb[i].customerId)
      {     
        this.bookingSer.deleteBooking(bookingId).subscribe(data=>{console.log(data)});
        this.bookingSer.bookingDb[i].bookingId=0;
        this.bookingSer.flag=true;
        this.flag1=true;
      }     
    }
  }
  }

}
