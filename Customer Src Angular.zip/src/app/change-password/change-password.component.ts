import { Component, OnInit } from '@angular/core';
import { BookingService } from '../booking.service';
import { Router } from '@angular/router';
import { BusService } from '../bus.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit 
{
  flag1:boolean;
  passwordFlag:boolean;
  tempCustomer:any;
  constructor(private custSer:CustomerService,private router:Router) { }
  changepassword = new FormGroup({
    customerEmail: new FormControl('',Validators.required),
    oldPassword: new FormControl('',Validators.required),
    newPassword: new FormControl('',Validators.required),
    reNewPassword: new FormControl('',Validators.required)
  })
    ngOnInit(): void 
    {
      this.custSer.getCustomer();
    }
  changePassword()
  {
    if(this.changepassword.valid)
    {
      this.flag1=false;
      this.passwordFlag=false;
  let customerEmail = this.changepassword.get('customerEmail').value;
  let oldPassword=this.changepassword.get('oldPassword').value;
  let newPassword=this.changepassword.get('newPassword').value;
  let reNewPassword=this.changepassword.get('reNewPassword').value;
    
      if (this.custSer.tempCustomer.customerEmail == customerEmail)
      {     
        if(this.custSer.tempCustomer.customerPassword==oldPassword)
        {
          this.flag1=true;
          if(newPassword==reNewPassword)
          {
            this.passwordFlag=true;
            this.custSer.tempCustomer.customerPassword=newPassword;
            this.tempCustomer=this.custSer.tempCustomer;
            this.custSer.updateCustomer(this.custSer.tempCustomer.customerId,this.tempCustomer).subscribe(data=>{console.log(data)});
            this.custSer.flag=true;
            this.flag1=true;
            this.router.navigateByUrl("/profile");
          }
        }
      }     
    
  }
}
}