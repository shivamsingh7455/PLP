import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Bus } from './Bus';


@Injectable({
  providedIn: 'root'
})
export class BusService 
{
  private localurl='http://localhost:8080/bus';
  public tempBus:Bus;
  public flag:boolean=false;
  public busDb:any[]=[];
  constructor(private http:HttpClient) { }
  httpOptions={
    headers:new HttpHeaders({
      'Content-Type':'application/json'
    })
}
  getBus()
  {
   this.http.get<Bus[]>(this.localurl).subscribe(resp=>
   {
    for(const b of(resp as any))
    {
      this.busDb.push
      ({
        busId:b.busId,
    sourceStation:b.sourceStation,
    destinationStation:b.destinationStation,
    boardingTime:b.boardingTime,
    dropTime:b.dropTime,
    busType:b.busType,
    totalSeats:b.totalSeats,
    fare:b.fare,
    seatNo:b.seatNo,
    seatsBooked:b.seatsBooked
      })
    }
  });
  }
  addBus(Bus:Bus)
  {
    return this.http.post(this.localurl+'/new',Bus);
  }

  deleteBus(busId:any)
  {
    return this.http.delete(this.localurl+'/'+busId);
  }
 
  updateBus(busId:any,Bus:Bus)
  {
    return this.http.put(this.localurl+'/'+busId,Bus);
  }
    
}
