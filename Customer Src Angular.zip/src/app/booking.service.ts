import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Booking } from './Booking';

@Injectable({
  providedIn: 'root'
})
export class BookingService
{
  private localurl='http://localhost:8080/booking';
  public tempBooking:Booking;
  public flag:boolean=false;
  public bookingDb:any[]=[];
  constructor(private http:HttpClient) { }
  httpOptions={
    headers:new HttpHeaders({
      'Content-Type':'application/json'
    })
}
  getBooking()
  {
   this.http.get<Booking[]>(this.localurl).subscribe(resp=>{
    for(const bk of(resp as any)){
      this.bookingDb.push({
        bookingId:bk.bookingId,
        busId:bk.busId,
        customerId:bk.customerId,
        passengerNames:bk.passengerNames,
        seatBooked:bk.seatBooked,
        passengerEmail:bk.passengerEmail,
        totalFare:bk.totalFare,
    feedBack:bk.feedBack,
    rating:bk.rating,
      })
    }
   
   
  });
  }
  addBooking(Booking:Booking)
  {
    return this.http.post(this.localurl+'/new',Booking);
  }

  deleteBooking(bookingId:any)
  {
    return this.http.delete(this.localurl+'/'+bookingId);
  }
 
  updateBooking(bookingId:any,Booking:Booking)
  {
    return this.http.put(this.localurl+'/'+bookingId,Booking);
  }
    
}