import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { BookingService } from '../booking.service';
import { Router } from '@angular/router';
import { BusService } from '../bus.service';
import { Booking } from '../Booking';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-generate-ticket',
  templateUrl: './generate-ticket.component.html',
  styleUrls: ['./generate-ticket.component.css']
})
export class GenerateTicketComponent implements OnInit {
  booking:Booking[]=[];
  flag1:any;
  constructor(private bookingSer:BookingService,private router:Router,private busSer:BusService,private custSer:CustomerService) { }
  generateticket = new FormGroup({
    busId: new FormControl('',Validators.required),
    bookingId: new FormControl('',Validators.required)
  })
    ngOnInit(): void 
    {
      // this.bookingSer.getBooking();
      // this.busSer.getBus();
    }
  generateTicket()
  {
  if(this.generateticket.valid)
    {
      this.flag1=false;
    let busId = this.generateticket.get('busId').value;
    let bookingId=this.generateticket.get('bookingId').value;
      let k=0;
      for(let i=0;i<this.bookingSer.bookingDb.length;i++) 
      {
        if (this.bookingSer.bookingDb[i].busId == busId&&this.bookingSer.bookingDb[i].bookingId==bookingId&&this.bookingSer.bookingDb[i].bookingId!=0)
        {     
          if(this.bookingSer.bookingDb[i].customerId==this.custSer.tempCustomer.customerId)
          {
          this.booking[0]=this.bookingSer.bookingDb[i];
          this.bookingSer.flag=true;
          this.flag1=true;
          }
        }     
      }
    }
  }

}
