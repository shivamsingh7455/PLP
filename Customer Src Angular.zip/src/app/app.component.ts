import { Component, OnInit } from '@angular/core';
import {BusService} from './bus.service';
import { BookingService } from './booking.service';
import { CustomerService } from './customer.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
  
})
export class AppComponent implements OnInit 
{
  title = 'BusBookingManagementSystem';
  flag1:any;
  constructor( private busSer:BusService, private BookingSer:BookingService, private CustomerSer:CustomerService)
  {
  }
  ngOnInit()
  {
    this.busSer.getBus();
    this.BookingSer.getBooking();
    this.CustomerSer.getCustomer();
  }
  run()
  {
    this.flag1==true;
  }

}
