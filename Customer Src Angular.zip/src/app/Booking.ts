export class Booking
{
    bookingId:any;
    busId:any;
    customerId:any;
    passengerNames:any;
    seatBooked:any;
    passengerEmail:any;
    totalFare:any;
    feedBack:any;
    rating:any;
    
    constructor(bookingId,busId,customerId,passengerNames,seatBooked,passengerEmail,totalFare,feedBack,rating)
    {
        this.bookingId=bookingId;
        this.busId=busId;
        this.customerId=customerId;
        this.passengerNames=passengerNames;
        this.seatBooked=seatBooked;
        this.passengerEmail=passengerEmail;
        this.totalFare=totalFare;
        this.feedBack=feedBack;
        this.rating=rating;
    }
}