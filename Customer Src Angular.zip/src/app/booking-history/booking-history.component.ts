import { Component, OnInit } from '@angular/core';
import { BookingService } from '../booking.service';
import { CustomerService } from '../customer.service';
import { Booking } from '../Booking';

@Component({
  selector: 'app-booking-history',
  templateUrl: './booking-history.component.html',
  styleUrls: ['./booking-history.component.css']
})
export class BookingHistoryComponent implements OnInit {
  booking:Booking[]=[];
  flag:boolean;
  constructor(private bookingSer:BookingService,private custSer:CustomerService) { }

  ngOnInit(): void 
  {
  }
  bookingHistory()
  {
    let k=0;
    this.booking=[];
    console.log(this.bookingSer.bookingDb.length);
    for(let i=0;i<this.bookingSer.bookingDb.length;i++)
    {
      if(this.bookingSer.bookingDb[i].customerId==this.custSer.tempCustomer.customerId&&this.bookingSer.bookingDb[i].bookingId!=0)
        {
          this.booking[k++]=this.bookingSer.bookingDb[i];
          this.flag=true;
        }
    }
    k=0;       
  }

}
