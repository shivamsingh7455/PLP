import { Injectable } from '@angular/core';
import { Customer } from './Customer';
import { HttpHeaders, HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  private localurl='http://localhost:8080/customer';
  public tempCustomer:Customer;
  public flag:boolean=false;
  public customerDb:any[]=[];
  constructor(private http:HttpClient) { }
  httpOptions={
    headers:new HttpHeaders({
      'Content-Type':'application/json'
    })
}
  getCustomer()
  {
   this.http.get<Customer[]>(this.localurl).subscribe(resp=>{
    for(const c of(resp as any)){
      this.customerDb.push({
        customerName:c.customerName,
    customerPhoneNumber:c.customerPhoneNumber,
    customerEmail:c.customerEmail,
    customerId:c.customerId,
    customerUserName:c.customerUserName,
    customerPassword:c.customerPassword,
    age:c.age
      })
    }
   
   
  });
  }
  addCustomer(Customer:Customer)
  {
    return this.http.post(this.localurl+'/new',Customer);
  }

  deleteCustomer(customerId:any)
  {
    return this.http.delete(this.localurl+'/'+customerId);
  }
 
  updateCustomer(customerId:any,Customer:Customer)
  {
    return this.http.put(this.localurl+'/'+customerId,Customer);
  }
}
