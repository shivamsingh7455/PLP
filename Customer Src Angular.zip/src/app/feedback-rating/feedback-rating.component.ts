import { Component, OnInit } from '@angular/core';
import { BookingService } from '../booking.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Booking } from '../Booking';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-feedback-rating',
  templateUrl: './feedback-rating.component.html',
  styleUrls: ['./feedback-rating.component.css']
})
export class FeedbackRatingComponent implements OnInit {
  flag1:any;
  tempBooking:Booking;
  constructor(private bookSer:BookingService,private router:Router,private custSer:CustomerService) { }
  feedback = new FormGroup({
    bookingId: new FormControl('',Validators.required),
    feedback: new FormControl('',Validators.required),
    rating: new FormControl('',Validators.required)
  })
    ngOnInit(): void 
    {
      // this.bookSer.getBooking();
    }
  feedbackRating()
  {
  if(this.feedback.valid)
  {
    console.log(this.custSer.tempCustomer.customerId);
    this.flag1=false;
  let bookingId = this.feedback.get('bookingId').value;
  let feedback=this.feedback.get('feedback').value;
  let rating=this.feedback.get('rating').value;
    for(let i=0;i<this.bookSer.bookingDb.length;i++) 
    {
      if (this.bookSer.bookingDb[i].bookingId==bookingId)
      {     
        console.log(this.bookSer.bookingDb[i].customerId);
        if(this.custSer.tempCustomer.customerId==this.bookSer.bookingDb[i].customerId)
        {
            this.bookSer.bookingDb[i].feedBack=feedback;
            this.bookSer.bookingDb[i].rating=rating;
            this.tempBooking=this.bookSer.bookingDb[i];
            this.bookSer.updateBooking(this.bookSer.bookingDb[i].bookingId,this.tempBooking).subscribe(data=>{console.log(data)});
            this.bookSer.flag=true;  
            this.flag1=true;
        }
      }     
    }
  }
  }

}
