package com.cg.web.obtrs.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.cg.web.obtrs.entities.BookingEntity;
import com.cg.web.obtrs.entities.BusEntity;

@Service
public interface AdminService {
	boolean login(String email, String password);

	List<BusEntity> getAllBus();

	BusEntity addBusOrRoute(BusEntity bus);

	Optional<BusEntity> getBus(Integer busId);

	List<BookingEntity> getAllBooking();

	Optional<BookingEntity> getBooking(Integer bookingId);

	List<BookingEntity> getBookingbyBusId(Integer busId);

	List<Integer> cancelBooking(Integer bookingId);

	List<BusEntity> updateBusBySourceStation(Integer busId, String sourceStation);

	List<BusEntity> updateBusByDestinationStation(Integer busId, String destinationStation);

	List<BusEntity> updateBusByBoardingTime(Integer busId, String boardingTime);

	List<BusEntity> updateBusByDropTime(Integer busId, String dropTime);

	List<BusEntity> updateBusByBusType(Integer busId, String busType);

	List<BusEntity> updateBusByTotalSeats(Integer busId, int totalSeats);

	List<BusEntity> updateBusByFare(Integer busId, float fare);

}
